Pulse — Pharmacy Operating System
=================================

WHAT THIS IS
------------
This package contains a launcher (Pulse.bat) that opens the Pulse
pharmacy management web app in your default browser. No installation
required — Pulse runs as a Progressive Web App (PWA) you can
bookmark or install to your desktop.

SYSTEM REQUIREMENTS
-------------------
- Windows 10+ (64-bit)
- Any modern browser (Chrome, Edge, Firefox)
- Internet connection

HOW TO USE
----------
1. Double-click Pulse.bat
   - Pulse opens in your default browser
2. Bookmark the URL or, in Chrome/Edge, click the install icon
   in the address bar to add Pulse to your Start menu / desktop

CREATE A DESKTOP SHORTCUT
-------------------------
- Right-click Pulse.bat → Send to → Desktop (create shortcut)
- Rename the desktop shortcut to "Pulse"
- Right-click the shortcut → Properties → Change Icon
- Browse to Pulse.ico (included in this package)

NEED HELP?
---------
- Web: https://duniya-web.onrender.com
- Email: support@duniyahealthcare.com
