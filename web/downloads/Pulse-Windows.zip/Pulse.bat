@echo off
REM ════════════════════════════════════════════════════════════════
REM   Pulse — Pharmacy Operating System
REM   Launcher for Windows. Opens the Pulse web app in your default
REM   browser. No installation required.
REM ════════════════════════════════════════════════════════════════
setlocal
set PULSE_URL=https://duniya-web.onrender.com/app.html

echo.
echo  ╔═══════════════════════════════════════════════════════════════╗
echo  ║  Pulse — Pharmacy Intelligence, Delivered.                  ║
echo  ╚═══════════════════════════════════════════════════════════════╝
echo.
echo  Launching the Pulse web app in your default browser...
echo  URL: %PULSE_URL%
echo.
echo  Tip: Press Ctrl+D to bookmark Pulse after it opens.
echo  Tip: For a desktop shortcut, drag this .bat file to your desktop.
echo.

start "" "%PULSE_URL%"

endlocal
