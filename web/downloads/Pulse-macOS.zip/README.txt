Pulse — Pharmacy Operating System
=================================

WHAT THIS IS
------------
This package contains a launcher (Pulse.command) that opens the
Pulse pharmacy management web app in your default browser. No
installation required — Pulse runs as a Progressive Web App (PWA)
you can bookmark or install to your Applications folder.

SYSTEM REQUIREMENTS
-------------------
- macOS 12+ (Apple Silicon or Intel)
- Any modern browser (Safari, Chrome, Firefox)
- Internet connection

HOW TO USE
----------
1. Double-click Pulse.command
   - If macOS shows "Pulse.command cannot be opened because it is
     from an unidentified developer", right-click → Open → Open.
   - Pulse opens in your default browser.
2. Bookmark the URL or, in Safari/Chrome, click the install icon
   in the address bar to add Pulse to your Applications folder.

CREATE A DOCK SHORTCUT
----------------------
- Drag Pulse.command to the right side of your Dock (next to the Trash)
- Or save the URL as a .webloc file via Safari: File → Save As

NEED HELP?
---------
- Web: https://duniya-web.onrender.com
- Email: support@duniyahealthcare.com
