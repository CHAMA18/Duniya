#!/bin/bash
# ════════════════════════════════════════════════════════════════
#   Pulse — Pharmacy Operating System
#   Launcher for macOS. Opens the Pulse web app in the default
#   browser. No installation required.
# ════════════════════════════════════════════════════════════════
PULSE_URL="https://duniya-web.onrender.com/app.html"

echo ""
echo "  ╔═══════════════════════════════════════════════════════════════╗"
echo "  ║  Pulse — Pharmacy Intelligence, Delivered.                  ║"
echo "  ╚═══════════════════════════════════════════════════════════════╝"
echo ""
echo "  Launching the Pulse web app in your default browser..."
echo "  URL: $PULSE_URL"
echo ""
echo "  Tip: Press Cmd+D to bookmark Pulse after it opens."
echo "  Tip: In Safari/Chrome, click the install icon in the address"
echo "       bar to add Pulse to your Applications folder."
echo ""

open "$PULSE_URL"
